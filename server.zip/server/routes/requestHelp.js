// const express =  require('express');
// const router = express.Router();

// const authenticateUser = require('../middlewares/authenticateUser');
// const requestController = require('../controllers/requestController');


// // router.post("/requestHelp", authenticateUser, requestController );

// router.post("/requestHelp", requestController );

// module.exports = router;